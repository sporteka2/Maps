const webpack = require('webpack');
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const CssMinimizerPlugin = require("css-minimizer-webpack-plugin");

var path = require('path');

module.exports = {
    mode: 'development',
    devtool: 'source-map',
    devServer: {
        devMiddleware: {
            writeToDisk: true
        }
    },
    entry: {
        main: {
            import: './main.js',
        },
    },
    output: {
        path: path.resolve(__dirname, '../ol/'),
        library: "map"
    },
    plugins: [new MiniCssExtractPlugin()],
    module: {
        rules: [
            {
                test: /\.css$/i,
                use: [MiniCssExtractPlugin.loader, "css-loader"],
            },
        ],
    },
    optimization: {
        minimizer: [
            // For webpack@5 you can use the `...` syntax to extend existing minimizers (i.e. `terser-webpack-plugin`), uncomment the next line
            `...`,
            new CssMinimizerPlugin(),
        ],
    }
};
